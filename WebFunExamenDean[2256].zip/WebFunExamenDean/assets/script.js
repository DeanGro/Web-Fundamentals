var lives = 3;


var cards = [
    {
        type : "queen",
        img : "save-the-queen.png"
    },
    {
        type : "bomb",
        img : "bomb.png"
    },
    {
        type : "bomb",
        img : "bomb.png"
    },
    {
        type : "bomb",
        img : "bomb.png"
    },
    {
        type : "bomb",
        img : "bomb.png"
    },
    {
        type : "bomb",
        img : "bomb.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    },
    {
        type : "empty",
        img : "empty-card.png"
    }
];
console.log(cards);
function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
};
shuffleArray(cards);
console.log(cards);

/*/for (var i = 0; i < cards.length; i++){
    x = document.createElement('img');
    x.src = "assets/images/" + cards[i].img;
    x.alt = cards[i].type;
    document.body.appendChild(x);
};
/*/
for (var i = 0; i < cards.length; i++){
    x = document.createElement('img');
    x.src = "assets/images/card.png";
    x.alt = cards[i].type;
    x.setAttribute("class", "images");
    x.setAttribute("id", i);
    x.setAttribute("onclick", 'changeImg(this.id)');
    document.body.appendChild(x);
};


console.log(x);
console.log(x.alt);
function changeImg(x){
    console.log(x);
    el = document.getElementById(x);
        if(el.alt == "queen"){
            el.src = "assets/images/save-the-queen.png";
                y = document.createElement('p');
                y.innerHTML = "You won";
                document.body.appendChild(y);
            
        } else if(el.alt == "bomb"){
            el.src = "assets/images/bomb.png";
            lives = lives - 1;
            var spanText = document.getElementById('lives').innerText=lives;
            if(lives = 0){
            y = document.createElement('p');
            y.innerHTML = "Game over";
            document.body.appendChild(y);
            }
        } else{
            el.src = "assets/images/empty-card.png";
        }
};
